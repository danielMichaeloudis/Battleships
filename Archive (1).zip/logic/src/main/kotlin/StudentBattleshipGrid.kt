package studentLogic

import uk.ac.bournemouth.ap.battleshiplib.*
import uk.ac.bournemouth.ap.lib.matrix.MutableMatrix
import uk.ac.bournemouth.ap.battleshiplib.GuessResult
import uk.ac.bournemouth.ap.lib.matrix.ext.Coordinate
import java.util.*
import kotlin.random.Random


class StudentBattleshipGrid : BattleshipGrid {

    override val columns: Int = 10
    override val rows: Int = 10
    private var shipSizes = BattleshipGrid.DEFAULT_SHIP_SIZES
    private var random = Random
    private val grid: MutableMatrix<GuessCell> = MutableMatrix.Companion.invoke(columns, rows, GuessCell.UNSET)

    constructor(shipSizes: IntArray = BattleshipGrid.DEFAULT_SHIP_SIZES, random: Random = Random) {
        this.shipSizes = shipSizes
        this.random = random as Random.Default
    }
    override var opponent: StudentBattleshipOpponent = StudentBattleshipOpponent(10, 10, createShipList(shipSizes, random))

    constructor(opponent: StudentBattleshipOpponent){
        this.opponent = opponent
    }
    var shotAt: MutableList<Coordinate> = mutableListOf() //A list of all coordinates that has been shot at
    override val shipsSunk: BooleanArray = BooleanArray(opponent.ships.size)

    /**
     * Gives the value at the given coordinate
     *
     * **/
    override fun get(column: Int, row: Int): GuessCell {
        return grid[column, row]
    }

    /**
     * Shoots at a grid cell and returns the result of the shot
     * **/
    override fun shootAt(column: Int, row: Int): GuessResult {
        var result: GuessResult
        val shipAt: BattleshipOpponent.ShipInfo<StudentShip>? = opponent.shipAt(column, row)
        if (shipAt == null) {//sets to miss if no ship there
            grid[column, row] = GuessCell.MISS
            result = GuessResult.MISS
        }else if (isSunk(shipAt.index)) {//sets to sunk if ship is sunk at index
            grid[column, row] = GuessCell.SUNK(shipAt.index)
            result = GuessResult.SUNK(shipAt.index)
        } else {//sets it to hit if other
            grid[column, row] = GuessCell.HIT(shipAt.index)
            result = GuessResult.HIT(shipAt.index)
        }
        shotAt.add(Coordinate(column, row)) //adds the coordinate to shotAt
        fireGridChange(column, row)
        return result
    }

    /**
     *
     * Checks if a given ship is sunk
     *
     * @param shipIndex the index of the ship to be checked
     * @return true if the ship is sunk, false if not or if ship isnt found
     *
     * **/
    fun isSunk(shipIndex: Int): Boolean {
        if (shipIndex in opponent.ships.indices) { //checks if given ship is in list of ships
            var myShip: StudentShip = opponent.ships[shipIndex]
            var result: Boolean = true
            for (c in myShip.contains) {//itterates through coordinates in ship to check if any are unhit
                if (grid[c.x, c.y] == GuessCell.UNSET) result = false
            }
            return result
        }
        return false //returns false if ship not found
    }

    /**
     * makes a random shot at the grid, to be used as a computer shooting at player
     * **/
    fun rndShoot(){
        val random = Random
        var canUse = false
        var x: Int = 0
        var y: Int = 0
        while (!canUse) { //loop while the coordinate generated cant be used
            canUse = true
            x = random.nextInt(columns)
            y = random.nextInt(rows)
            if (shotAt.contains(Coordinate(x, y))) canUse = false // checks if the given coordinate has already been shot at
        }
        shootAt(x, y) //shoots when it finds an acceptable coordinate
    }

    /**
     * Checks if the player has had all their ships sunk
     *
     * **/
    fun checkLost(): Boolean{
        for (s in opponent.ships.indices) { //itterates through all ships to find an unsunk one
            if (!isSunk(s)) return false
        }
        return true
    }

    /**
     * creates a random list of non-overlapping ships that dont hang off the edge of the grid
     * **/
    private fun createShipList(shipSizes: IntArray = BattleshipGrid.DEFAULT_SHIP_SIZES, random: Random = Random): List<StudentShip> {
        var shipList: MutableList<StudentShip> = mutableListOf()
        for (i in shipSizes.indices) {
            var canUseShip: Boolean = false
            var newShip: StudentShip = StudentShip(0,0,0,0)
            while (!canUseShip) { //loop while ship isnt available to use
                canUseShip = true
                val shipSize = shipSizes[i]
                val top = random.nextInt(rows)
                val left = random.nextInt(columns) //create random values
                newShip = if (random.nextBoolean()) { //selects orientation
                    if (top + shipSize > 9) canUseShip = false //checks for going outside grid
                    StudentShip(top, left, top + shipSize, left) //creates a ship
                } else {
                    if (left + shipSize > 9) canUseShip = false //checks for going outside grid
                    StudentShip(top, left, top, left + shipSize) //creates a ship
                }
                for (c in shipList) {
                    for (c2 in newShip.contains) {
                        if (c2 in c.contains) canUseShip = false //checks if any coordinates overlap
                    }
                }
            }
            shipList.add(i, newShip)

        }
        return shipList
    }

    private val gridChangeListeners = mutableListOf<BattleshipGrid.BattleshipGridListener>()

    override fun addOnGridChangeListener(listener: BattleshipGrid.BattleshipGridListener){
        if (listener !in gridChangeListeners) {
            gridChangeListeners.add(listener)
        }
    }
    override fun removeOnGridChangeListener(listener: BattleshipGrid.BattleshipGridListener){
        gridChangeListeners.remove(listener)
    }

    private fun fireGridChange(column: Int, row: Int) {
        for(listener in gridChangeListeners) {
            listener.onGridChanged(this, column, row)
        }
    }


}