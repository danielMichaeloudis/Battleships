## logic module
This module is where you implement your game logic. It is independent of Android, can be tested
independently, and could potentially be used for other platforms.