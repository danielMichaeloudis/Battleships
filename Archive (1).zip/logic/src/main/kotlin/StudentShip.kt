package studentLogic
import uk.ac.bournemouth.ap.battleshiplib.Ship
import uk.ac.bournemouth.ap.lib.matrix.ext.Coordinate

class StudentShip(top: Int, left: Int, bottom: Int, right: Int) : Ship {

    override val top: Int = top
    override val left: Int = left
    override val bottom: Int = bottom
    override val right: Int = right
    val contains: MutableList<Coordinate> = mutableListOf()
    init {
        for (i in top..bottom){
            for (c in left..right){
                contains.add(Coordinate(i, c)) //itterates through coordinates adding to contains
            }
        }
    }

}