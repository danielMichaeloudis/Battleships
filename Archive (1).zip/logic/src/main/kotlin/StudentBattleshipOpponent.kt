package studentLogic

import uk.ac.bournemouth.ap.battleshiplib.BattleshipOpponent
import uk.ac.bournemouth.ap.lib.matrix.ext.Coordinate

class StudentBattleshipOpponent(columns: Int = 10, rows: Int = 10, ships: List<StudentShip>) : BattleshipOpponent {

    override val columns: Int = columns
    override val rows: Int = rows
    override var ships: List<StudentShip> =  ships

    /**
     * gives the ship at the given coordinates
     * **/
    override fun shipAt(column: Int, row: Int) : BattleshipOpponent.ShipInfo<StudentShip>? {
        var result:BattleshipOpponent.ShipInfo<StudentShip>? = null
        var i = 0
        for (ship in ships) {//itterates through ships to see if it contains the given coordinate
            if (ship.contains.contains(Coordinate(column, row))){
                result = BattleshipOpponent.ShipInfo(i, ship)
            }
            i += 1
        }
        return result
    }

}