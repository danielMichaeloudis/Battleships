package uk.ac.bournemouth.ap.battleships

import android.content.Context
import android.view.View
import android.util.AttributeSet
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.view.GestureDetector
import android.view.MotionEvent
import androidx.core.view.GestureDetectorCompat
import studentLogic.StudentBattleshipGrid
import studentLogic.StudentShip
import uk.ac.bournemouth.ap.battleshiplib.BattleshipGrid
import uk.ac.bournemouth.ap.battleshiplib.BattleshipOpponent
import uk.ac.bournemouth.ap.battleshiplib.GuessCell


class GridView : View {
    constructor(context: Context?) : super(context)
    constructor(context: Context?, attrs: AttributeSet?) : super(context, attrs)
    constructor(context: Context?, attrs: AttributeSet?, defStyleAttr: Int) : super(context, attrs, defStyleAttr)

    private val gridChangeListener: BattleshipGrid.BattleshipGridListener = BattleshipGrid.BattleshipGridListener { _: BattleshipGrid, _: Int, _: Int ->
        invalidate()
    }

    var grid: StudentBattleshipGrid = StudentBattleshipGrid()//grid for computer
    set(value){
        field = value
        recalculateDimentions()
        invalidate()
    }
    var gridPlayer: StudentBattleshipGrid = StudentBattleshipGrid()//grid for player
        set(value){
            field = value
            recalculateDimentions()
            invalidate()
        }

    private val colCount get() = grid.columns
    private val rowCount get() = grid.rows

    private var squareSize: Float = 0f
    private var squareSpacing: Float = 0f
    private var spacingRatio: Float = 0.2f

    private val gridPaint: Paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.WHITE
    }

    private val emptyPaint: Paint= Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.WHITE
    }

    private val gridLeft: Float = 0f
    private val gridTop: Float = 0f
    private val gridRight: Float = gridLeft + colCount * (squareSize+squareSpacing) + squareSpacing
    private val gridBottom: Float = gridTop + rowCount * (squareSize+squareSpacing) + squareSpacing

    //circle and text colors
    private val labelCol: Int = Color.YELLOW
    //paint variables
    private var missPaint: Paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { //colour for miss on opponent grid and sunk on player grid
        style = Paint.Style.FILL
        color = Color.RED
    }
    private var hitPaint: Paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {//colour for hit
        style = Paint.Style.FILL
        color = Color.YELLOW
    }
    private var sunkPaint: Paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { //colour for sunk on opponent grid and miss on player grid
        style = Paint.Style.FILL
        color = Color.GREEN
    }
    private var shipPaint: Paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {//colour for unhit ship on player grid
        style = Paint.Style.FILL
        color = Color.BLUE
    }
    private var wordsPaint: Paint = Paint().apply {
        color = Color.WHITE

        //set text properties
        textAlign = Paint.Align.CENTER
        textSize = 100f
        typeface = Typeface.SANS_SERIF
    }

    private var inGame: Boolean = true

    init {
        grid.addOnGridChangeListener(gridChangeListener) //adds listeners for both grids
        gridPlayer.addOnGridChangeListener(gridChangeListener)
    }

    var halfSize = squareSize / 2f
    var centralAligner = (width - (gridLeft + colCount * (squareSize+squareSpacing) + squareSpacing)) / 2

    override fun onDraw(canvas: Canvas) {
        //super.onDraw(canvas)
        halfSize = squareSize / 2f
        centralAligner = (width - (gridLeft + colCount * (squareSize+squareSpacing) + squareSpacing)) / 2
        canvas.drawRect(gridLeft, gridTop, gridRight, gridBottom, gridPaint)
        canvas.drawText("Guesses", (width / 2).toFloat(), gridTop + 100, wordsPaint)
        if (inGame) {
            for (row in 0 until rowCount) {
                val cy =
                    gridTop + 150 + squareSpacing + ((squareSize + squareSpacing) * row) + halfSize

                for (col in 0 until colCount) {
                    var paint = emptyPaint
                    val shipAt: BattleshipOpponent.ShipInfo<StudentShip>? = grid.opponent.shipAt(col, row)
                    if (grid[col, row] == GuessCell.MISS) paint = missPaint
                    else if (shipAt != null) {
                        println("there is a ship at :" + col + "," + row + ".")
                        if (grid.isSunk(shipAt.index)) paint = sunkPaint
                        else if (grid[col, row] == GuessCell.HIT(shipAt.index)) paint = hitPaint
                    }

                    val cx = gridLeft + squareSpacing + ((squareSize + squareSpacing) * col) + halfSize + centralAligner

                    canvas.drawRect(
                        cx - halfSize,
                        cy - halfSize,
                        cx + halfSize,
                        cy + halfSize,
                        paint
                    )
                }
            }

            //val newTop = gridTop + 150 + squareSpacing + ((squareSize + squareSpacing) * rowCount) + halfSize
            val newTop: Int = height / 2
            canvas.drawText("Ships", (width / 2).toFloat(), (newTop + 100).toFloat(), wordsPaint)
            for (row in 0 until rowCount) {
                val cy =
                    newTop + 150 + squareSpacing + ((squareSize + squareSpacing) * row) + halfSize

                for (col in 0 until colCount) {
                    var paint = emptyPaint
                    val shipAt: BattleshipOpponent.ShipInfo<StudentShip>? =
                        gridPlayer.opponent.shipAt(col, row)
                    if (gridPlayer[col, row] == GuessCell.MISS) paint = sunkPaint
                    else if (shipAt != null) {
                        if (gridPlayer.isSunk(shipAt.index)) paint = missPaint
                        else if (gridPlayer[col, row] == GuessCell.HIT(shipAt.index)) paint = hitPaint
                        else paint = shipPaint
                    }

                    val cx =
                        gridLeft + squareSpacing + ((squareSize + squareSpacing) * col) + halfSize + centralAligner

                    canvas.drawRect(
                        cx - halfSize,
                        cy - halfSize,
                        cx + halfSize,
                        cy + halfSize,
                        paint
                    )
                }
            }
        }
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        recalculateDimentions(w, h)
    }

    private fun recalculateDimentions(w: Int =  width, h: Int = height) {
        if (height > width) {
            val sizeX = w/(colCount + (colCount+1)*spacingRatio)
            val sizeY = (h - 250)/((rowCount + (rowCount+1)*spacingRatio) * 2)
            squareSize = minOf(sizeX, sizeY)
            println(squareSize)
            squareSpacing = squareSize * spacingRatio
        }else {
            println("test")
        }
    }

    private val gestureDetector = GestureDetectorCompat(context, object:
        GestureDetector.SimpleOnGestureListener() {

        override fun onDown(e: MotionEvent): Boolean = true

        override fun onSingleTapUp(e: MotionEvent): Boolean {
            var columnTouched = ((e.x - squareSpacing * 0.5f - centralAligner / 2f) / (squareSpacing + squareSize)).toInt()
            var gridTouched: Float
            if (e.y < height/2) {
                gridTouched = 1f
            }else {
                gridTouched = 2f
            }
            var rowTouched = (((e.y - squareSpacing * 0.5f - (height*(gridTouched - 1f))/2f - 250f) / (squareSpacing + squareSize)) + 1).toInt()

            if ((columnTouched in 0 until grid.columns) && (rowTouched in 0 until grid.rows) && gridTouched == 1f){ //only if tapped in a cell on the top grid
                grid.shootAt(columnTouched, rowTouched)
                if (grid.checkLost()) {
                    //TODO player won
                }
                gridPlayer.rndShoot()
                if (gridPlayer.checkLost()) {
                    //TODO player lost
                }
            }

            return super.onSingleTapUp(e)
        }
    })

    override fun onTouchEvent(event: MotionEvent): Boolean {
        return gestureDetector.onTouchEvent(event) || super.onTouchEvent(event)
    }

}